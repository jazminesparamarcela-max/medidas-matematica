# Medidas de longitud

Aplicación educativa en español argentino para estudiantes de secundaria. Incluye explicaciones sobre las unidades de longitud, ejemplos de selección de unidades, un conversor interactivo y ejercicios con devoluciones paso a paso.

Es una app estática: no necesita cuentas, servidor, base de datos ni servicios de IA. El progreso y los resultados se guardan en el navegador de cada estudiante.

## Publicarla gratis en GitHub Pages

1. Creá un repositorio nuevo en GitHub.
2. Copiá **el contenido de esta carpeta** a la raíz de ese repositorio. No hace falta subir el resto del proyecto.
3. En el repositorio, abrí **Settings → Pages** y elegí **GitHub Actions** como fuente.
4. Subí el contenido a la rama `main`. El flujo de GitHub Actions compila y publica el sitio automáticamente.
5. Cuando termine la acción, GitHub muestra el enlace público de Pages. Ese enlace se puede compartir por WhatsApp.

Si la rama principal del repositorio tiene otro nombre, cambiá `main` en `.github/workflows/pages.yml`.

## Ejecutarla en la computadora

Requiere Node.js 24 o posterior y pnpm:

```bash
pnpm install
pnpm dev
```

Para generar los archivos estáticos:

```bash
pnpm build
```

El resultado queda en `dist/public/`. El flujo de GitHub Pages configura la ruta base según el nombre del repositorio.

## Privacidad

No se envían respuestas ni resultados a ningún servidor. El progreso de las prácticas se conserva solamente en el almacenamiento local del navegador; por eso no se comparte entre dispositivos o navegadores distintos.
