import { useEffect, useState, type FormEvent } from 'react';
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Check,
  Compass,
  Lightbulb,
  MoveRight,
  Ruler,
  RotateCcw,
} from 'lucide-react';

type Section = 'inicio' | 'aprender' | 'unidades' | 'mision';
type Unit = 'km' | 'hm' | 'dam' | 'm' | 'dm' | 'cm' | 'mm';
type PracticeUnit = 'km' | 'm' | 'cm' | 'mm';
type Question = {
  kind: 'choice' | 'typed';
  prompt: string;
  answer: string;
  choices?: string[];
  explanation: string;
  questionLabel: string;
  unit?: PracticeUnit;
};

const allUnits: { key: Unit; name: string; meters: number }[] = [
  { key: 'km', name: 'kilómetro', meters: 1000 },
  { key: 'hm', name: 'hectómetro', meters: 100 },
  { key: 'dam', name: 'decámetro', meters: 10 },
  { key: 'm', name: 'metro', meters: 1 },
  { key: 'dm', name: 'decímetro', meters: 0.1 },
  { key: 'cm', name: 'centímetro', meters: 0.01 },
  { key: 'mm', name: 'milímetro', meters: 0.001 },
];

const questions: Question[] = [
  {
    kind: 'choice',
    prompt: 'Un tramo de ruta mide 4 km. ¿Cuántos metros son?',
    answer: '4.000 m',
    choices: ['400 m', '4.000 m', '40.000 m', '40 m'],
    explanation: 'De km a m hay tres saltos hacia una unidad más chica: multiplicamos por 1.000. 4 × 1.000 = 4.000.',
    questionLabel: 'Conversión · opción múltiple',
  },
  {
    kind: 'typed',
    prompt: 'Una caminata mide 8.000 m. ¿Cuántos kilómetros son?',
    answer: '8',
    unit: 'km',
    explanation: 'Pasamos de metros a kilómetros, una unidad más grande: dividimos por 1.000. 8.000 ÷ 1.000 = 8 km.',
    questionLabel: 'Conversión · respuesta abierta',
  },
  {
    kind: 'choice',
    prompt: 'Una cinta tiene 600.000 cm. ¿Cuántos kilómetros mide?',
    answer: '6 km',
    choices: ['60 km', '600 km', '6 km', '6.000 km'],
    explanation: 'Un kilómetro contiene 100.000 centímetros. Entonces 600.000 ÷ 100.000 = 6 km.',
    questionLabel: 'Conversión · opción múltiple',
  },
  {
    kind: 'choice',
    prompt: 'Una carrera tiene un recorrido de 5.000 metros. ¿Qué unidad conviene para expresar esa distancia?',
    answer: 'km',
    choices: ['km', 'm', 'cm', 'mm'],
    explanation: 'Para una carrera, los kilómetros son una unidad habitual. 5.000 m son 5 km: un número más corto y fácil de leer.',
    questionLabel: 'Selección de unidad · contexto',
  },
  {
    kind: 'typed',
    prompt: 'Un camino mide 7 km. ¿Cuántos centímetros son?',
    answer: '700000',
    unit: 'cm',
    explanation: 'Cada km tiene 1.000 m y cada metro, 100 cm. En total, 1 km = 100.000 cm; 7 × 100.000 = 700.000 cm.',
    questionLabel: 'Conversión · respuesta abierta',
  },
  {
    kind: 'choice',
    prompt: 'Una pared mide 3.200 m de largo. ¿Cuántos centímetros son?',
    answer: '320.000 cm',
    choices: ['32.000 cm', '320.000 cm', '3.200 cm', '3.200.000 cm'],
    explanation: 'De m a cm bajamos dos unidades en la escala: multiplicamos por 100. 3.200 × 100 = 320.000 cm.',
    questionLabel: 'Conversión · opción múltiple',
  },
  {
    kind: 'typed',
    prompt: 'Una tira mide 1.000.000 mm. ¿Cuántos kilómetros son?',
    answer: '1',
    unit: 'km',
    explanation: 'Un km equivale a 1.000.000 mm. Para pasar a una unidad mayor, dividimos: 1.000.000 ÷ 1.000.000 = 1 km.',
    questionLabel: 'Conversión · respuesta abierta',
  },
  {
    kind: 'choice',
    prompt: 'Para anotar el grosor de una moneda, ¿qué unidad te permite ser más preciso sin usar un número enorme?',
    answer: 'mm',
    choices: ['km', 'm', 'cm', 'mm'],
    explanation: 'El grosor es muy pequeño. Los milímetros permiten describirlo con un número manejable y buena precisión.',
    questionLabel: 'Elegir unidad · situación',
  },
  {
    kind: 'choice',
    prompt: 'Una tela mide 250.000 cm. ¿Cuántos metros son?',
    answer: '2.500 m',
    choices: ['250 m', '25.000 m', '2.500 m', '250.000 m'],
    explanation: 'De cm a m subimos dos pasos, así que dividimos por 100: 250.000 ÷ 100 = 2.500 m.',
    questionLabel: 'Conversión · opción múltiple',
  },
  {
    kind: 'choice',
    prompt: 'Para medir el largo de un lápiz, ¿qué unidad suele ser la más práctica?',
    answer: 'cm',
    choices: ['km', 'm', 'cm', 'mm'],
    explanation: 'Los centímetros son cómodos para objetos que entran en la mano: dan un número sencillo y suficiente precisión.',
    questionLabel: 'Selección de unidad · contexto',
  },
  {
    kind: 'typed',
    prompt: 'Una pieza mide 50.000 mm. ¿Cuántos centímetros son?',
    answer: '5000',
    unit: 'cm',
    explanation: 'De mm a cm subimos un paso y dividimos por 10. 50.000 ÷ 10 = 5.000 cm.',
    questionLabel: 'Conversión · respuesta abierta',
  },
  {
    kind: 'choice',
    prompt: 'Un recorrido mide 3.000 m. ¿Cuántos kilómetros son?',
    answer: '3 km',
    choices: ['30 km', '300 km', '3 km', '3.000 km'],
    explanation: 'De m a km subimos tres pasos en la escala: dividimos por 1.000. 3.000 ÷ 1.000 = 3 km.',
    questionLabel: 'Conversión · opción múltiple',
  },
];

const contexts = [
  ['Distancia entre dos ciudades', 'La distancia puede ser grande: así se lee de un vistazo.', 'km'],
  ['Largo o ancho de una casa o terreno', 'Para lados y medidas de ambientes, el metro suele dar números cómodos.', 'm'],
  ['Altura de una pared o un techo', 'Los metros expresan bien una altura de tamaño humano.', 'm'],
  ['Puertas y ventanas', 'El centímetro da detalle útil para elegir o comprobar medidas.', 'cm'],
  ['Talle de ropa', 'Las tablas de talles suelen comparar medidas del cuerpo en centímetros.', 'cm'],
  ['Un tramo de tela', 'Para cortar varios metros, los metros ayudan a organizar el largo.', 'm'],
  ['Un tornillo o una chapa fina', 'Si hace falta precisión, los milímetros muestran pequeñas diferencias.', 'mm'],
  ['Un lápiz o el ancho de una mano', 'Son objetos chicos, pero los centímetros siguen siendo fáciles de usar.', 'cm'],
  ['Una carrera en la plaza', 'Los metros son prácticos para circuitos y vueltas cortas.', 'm'],
  ['El grosor de una moneda', 'Es una medida diminuta: los milímetros la describen mejor.', 'mm'],
];

function formatNumber(value: number, maxDigits = 6) {
  return new Intl.NumberFormat('es-AR', {
    maximumFractionDigits: maxDigits,
    useGrouping: true,
  }).format(value);
}

function parseLocalNumber(value: string) {
  const normalized = value.trim().replace(/\./g, '').replace(',', '.');
  if (!normalized || normalized === '-' || normalized === '.') return Number.NaN;
  return Number(normalized);
}

function App() {
  const [section, setSection] = useState<Section>('inicio');
  const [amount, setAmount] = useState('3,5');
  const [fromUnit, setFromUnit] = useState<Unit>('m');
  const [toUnit, setToUnit] = useState<Unit>('cm');
  const [questionIndex, setQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState('');
  const [typedAnswer, setTypedAnswer] = useState('');
  const [checkedAnswer, setCheckedAnswer] = useState(false);
  const [streak, setStreak] = useState(0);
  const [roundScore, setRoundScore] = useState(0);
  const [bestScore, setBestScore] = useState(() => {
    try {
      return Number(localStorage.getItem('mision-medidas-best') || 0);
    } catch {
      return 0;
    }
  });
  const [completedRounds, setCompletedRounds] = useState(() => {
    try {
      return Number(localStorage.getItem('mision-medidas-rounds') || 0);
    } catch {
      return 0;
    }
  });
  const [roundComplete, setRoundComplete] = useState(false);

  const currentQuestion = questions[questionIndex];
  const parsedAmount = parseLocalNumber(amount);
  const conversion = Number.isFinite(parsedAmount)
    ? (parsedAmount * allUnits.find((item) => item.key === fromUnit)!.meters) /
      allUnits.find((item) => item.key === toUnit)!.meters
    : Number.NaN;
  const fromIndex = allUnits.findIndex((unit) => unit.key === fromUnit);
  const toIndex = allUnits.findIndex((unit) => unit.key === toUnit);
  const steps = Math.abs(fromIndex - toIndex);
  const factor = 10 ** steps;
  const operation = fromIndex < toIndex ? 'multiplicamos' : fromIndex > toIndex ? 'dividimos' : 'no cambia';
  const isCorrect = currentQuestion?.kind === 'choice'
    ? selectedAnswer === currentQuestion.answer
    : parseLocalNumber(typedAnswer) === Number(currentQuestion?.answer);

  useEffect(() => {
    try {
      localStorage.setItem('mision-medidas-best', String(bestScore));
      localStorage.setItem('mision-medidas-rounds', String(completedRounds));
    } catch {
      // La práctica sigue funcionando aunque el navegador no permita guardar.
    }
  }, [bestScore, completedRounds]);

  const navItems: { key: Section; label: string }[] = [
    { key: 'inicio', label: 'Inicio' },
    { key: 'aprender', label: 'Conceptos' },
    { key: 'unidades', label: 'Elegir unidad' },
    { key: 'mision', label: 'Practicar' },
  ];

  function goTo(next: Section) {
    setSection(next);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function answerChoice(choice: string) {
    if (checkedAnswer) return;
    setSelectedAnswer(choice);
    setCheckedAnswer(true);
    const right = choice === currentQuestion.answer;
    setStreak(right ? streak + 1 : 0);
    if (right) setRoundScore((score) => score + 1);
  }

  function submitTyped(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (checkedAnswer || !typedAnswer.trim()) return;
    setCheckedAnswer(true);
    const right = parseLocalNumber(typedAnswer) === Number(currentQuestion.answer);
    setStreak(right ? streak + 1 : 0);
    if (right) setRoundScore((score) => score + 1);
  }

  function advanceQuestion() {
    if (questionIndex === questions.length - 1) {
      const finalScore = roundScore;
      setRoundComplete(true);
      setBestScore((best) => Math.max(best, finalScore));
      setCompletedRounds((rounds) => rounds + 1);
      return;
    }
    setQuestionIndex((index) => index + 1);
    setSelectedAnswer('');
    setTypedAnswer('');
    setCheckedAnswer(false);
  }

  function replayMission() {
    setQuestionIndex(0);
    setSelectedAnswer('');
    setTypedAnswer('');
    setCheckedAnswer(false);
    setRoundScore(0);
    setStreak(0);
    setRoundComplete(false);
  }

  const progressPercent = roundComplete
    ? 100
    : ((questionIndex + (checkedAnswer ? 1 : 0)) / questions.length) * 100;

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="topbar-inner">
          <button className="brand" onClick={() => goTo('inicio')} aria-label="Ir al inicio" data-testid="link-inicio">
            <span className="brand-mark"><Ruler size={20} strokeWidth={1.8} /></span>
            <span className="brand-copy"><strong>Medidas de longitud</strong><span>Matemática · Secundaria</span></span>
          </button>
          <nav className="nav-links" aria-label="Navegación principal">
            {navItems.map((item) => (
              <button
                key={item.key}
                type="button"
                className={`nav-button ${section === item.key ? 'active' : ''}`}
                aria-current={section === item.key ? 'page' : undefined}
                onClick={() => goTo(item.key)}
                data-testid={`nav-${item.key}`}
              >
                {item.label}
              </button>
            ))}
          </nav>
          <div className="progress-chip" data-testid="status-progreso">
            <Check size={15} aria-hidden="true" />
                    <span>{completedRounds} {completedRounds === 1 ? 'práctica' : 'prácticas'}</span>
          </div>
        </div>
      </header>

      <main>
        {section === 'inicio' && (
          <div className="page-wrap">
            <section className="hero" aria-labelledby="hero-title">
              <div className="hero-copy">
                <span className="eyebrow">Matemática · Sistema métrico decimal</span>
                <h1 id="hero-title">Medidas<br />de <em>longitud</em></h1>
                <p className="lede">Identificá las unidades de longitud, elegí cuál conviene usar y resolvé conversiones entre ellas.</p>
                <div className="hero-actions">
                  <button className="button button-primary" onClick={() => goTo('aprender')} data-testid="button-empezar">
                    Ver conceptos <ArrowRight size={16} />
                  </button>
                  <button className="button button-secondary" onClick={() => goTo('mision')} data-testid="button-ir-mision">
                    Practicar ejercicios <ArrowRight size={16} />
                  </button>
                </div>
              </div>
              <div className="hero-art" role="img" aria-label="Ilustración abstracta de una regla sobre un fondo verde suave">
                <div className="ruler-illustration" aria-hidden="true">
                  <span className="ruler-label">cm</span>
                  {Array.from({ length: 21 }, (_, index) => <span key={index} />)}
                </div>
                <div className="orbit-note note-one">Factor de conversión <strong>×10</strong></div>
                <div className="orbit-note note-two">Sistema<br />métrico decimal</div>
              </div>
            </section>

            <section aria-labelledby="path-title">
              <div className="section-heading">
                <div><span className="eyebrow">Contenidos</span><h2 id="path-title" style={{ margin: '10px 0 0' }}>Temas de estudio</h2></div>
                <p>Conceptos y ejercicios de aplicación.</p>
              </div>
              <div className="learning-path">
                <button className="path-card" onClick={() => goTo('aprender')} data-testid="card-aprender">
                  <span className="path-index">01 / CONCEPTOS</span><span className="path-icon"><Ruler size={18} /></span>
                  <h3>Unidades de longitud</h3><p>Estudiá las siete unidades y su relación en la escala métrica.</p>
                </button>
                <button className="path-card" onClick={() => goTo('unidades')} data-testid="card-unidades">
                  <span className="path-index">02 / APLICACIÓN</span><span className="path-icon"><Compass size={18} /></span>
                  <h3>Selección de unidades</h3><p>Elegí la unidad adecuada según la longitud y la precisión.</p>
                </button>
                <button className="path-card" onClick={() => goTo('mision')} data-testid="card-mision">
                  <span className="path-index">03 / PRÁCTICA</span><span className="path-icon"><Check size={18} /></span>
                  <h3>Ejercicios de conversión</h3><p>Resolvé doce ejercicios con una explicación para cada respuesta.</p>
                </button>
              </div>
            </section>
            <div className="fact-strip">
              <strong>Escala métrica decimal</strong>
              <span>km → hm → dam → m → dm → cm → mm</span>
            </div>
          </div>
        )}

        {section === 'aprender' && (
          <div className="page-wrap">
            <span className="eyebrow">01 · Conceptos</span>
            <h1 style={{ margin: '15px 0 14px' }}>Unidades de<br /><em style={{ color: 'hsl(var(--primary))' }}>longitud.</em></h1>
            <p className="lede">Las siete unidades del sistema métrico se ordenan de mayor a menor. Entre unidades consecutivas, el factor de conversión es 10.</p>
            <div className="unit-rail" aria-label="Unidades métricas ordenadas de mayor a menor">
              {allUnits.map((unit, index) => (
                <div className="unit-cell" key={unit.key} data-testid={`unidad-${unit.key}`}>
                  <span className="unit-symbol">{unit.key}</span><span className="unit-name">{unit.name}</span>
                  {index < allUnits.length - 1 && <span className="sr-only">Un paso equivale a multiplicar por diez hacia la derecha.</span>}
                </div>
              ))}
            </div>
            <div className="concept-grid">
              <article className="concept-card">
                <span className="concept-kicker">Conversión a una unidad menor</span>
                <h3>Multiplicar</h3>
                <p>La misma longitud se expresa con un número mayor. Multiplicamos por 10 por cada posición recorrida.</p>
                <div className="math-example" data-testid="ejemplo-multiplicar">3 cm = 30 mm &nbsp;·&nbsp; 3 m = 300 cm &nbsp;·&nbsp; 3 km = 3.000 m</div>
              </article>
              <article className="concept-card">
                <span className="concept-kicker">Conversión a una unidad mayor</span>
                <h3>Dividir</h3>
                <p>La misma longitud se expresa con un número menor. Dividimos por 10 por cada posición recorrida.</p>
                <div className="math-example" data-testid="ejemplo-dividir">5.000 m = 5 km &nbsp;·&nbsp; 400 cm = 4 m</div>
              </article>
            </div>
            <div className="note-callout">
              <Lightbulb size={19} aria-hidden="true" />
              <p><strong>La operación depende de la unidad de destino.</strong> Multiplicá para expresar la longitud en una unidad menor y dividí para una unidad mayor. Mover la coma decimal es un atajo; primero identificá el factor de conversión.</p>
            </div>
            <section className="converter" aria-labelledby="converter-title">
              <div>
                <span className="eyebrow" style={{ color: 'hsl(var(--primary-foreground))' }}>Conversión interactiva</span>
                <h3 id="converter-title" style={{ marginTop: 10 }}>Conversor de unidades</h3>
                <p className="muted">Ingresá un valor y seleccioná las unidades de origen y destino.</p>
              </div>
              <MoveRight size={25} aria-hidden="true" />
              <div className="converter-fields">
                <div className="field">
                    <label htmlFor="convert-amount">Valor</label>
                  <input id="convert-amount" inputMode="decimal" value={amount} onChange={(event) => setAmount(event.target.value)} aria-label="Número que quiero convertir" data-testid="input-convertir-numero" />
                </div>
                <div className="field">
                    <label htmlFor="convert-from">Unidad de origen</label>
                  <select id="convert-from" value={fromUnit} onChange={(event) => setFromUnit(event.target.value as Unit)} data-testid="select-unidad-origen">
                    {allUnits.map((unit) => <option key={unit.key} value={unit.key}>{unit.name} ({unit.key})</option>)}
                  </select>
                </div>
                <ArrowRight className="convert-arrow" size={19} aria-hidden="true" />
                <div className="field">
                    <label htmlFor="convert-to">Unidad de destino</label>
                  <select id="convert-to" value={toUnit} onChange={(event) => setToUnit(event.target.value as Unit)} data-testid="select-unidad-destino">
                    {allUnits.map((unit) => <option key={unit.key} value={unit.key}>{unit.name} ({unit.key})</option>)}
                  </select>
                </div>
              </div>
              <div className="converter-result" aria-live="polite" data-testid="resultado-conversion">
                <div>
                  <div className="result-value">{Number.isFinite(conversion) ? `${formatNumber(conversion)} ${toUnit}` : 'Escribí un número'}</div>
                  <div className="scale-readout" aria-label={`Escala desde ${fromUnit} hasta ${toUnit}`}>
                    {allUnits.map((unit, index) => (
                      <span className={index >= Math.min(fromIndex, toIndex) && index <= Math.max(fromIndex, toIndex) ? 'on' : ''} key={unit.key}>{unit.key}{index < allUnits.length - 1 && <i>—</i>}</span>
                    ))}
                  </div>
                </div>
                <div className="result-detail">
                  {fromIndex === toIndex
                    ? 'La unidad es la misma: el valor no cambia.'
                    : `Damos ${steps} ${steps === 1 ? 'salto' : 'saltos'} y ${operation} por ${formatNumber(factor)}.`}
                  <br />{fromIndex < toIndex ? <><ArrowDownRight size={14} style={{ verticalAlign: 'middle' }} /> Hacia unidades más chicas</> : fromIndex > toIndex ? <><ArrowUpRight size={14} style={{ verticalAlign: 'middle' }} /> Hacia unidades más grandes</> : 'Misma unidad'}
                </div>
              </div>
            </section>
          </div>
        )}

        {section === 'unidades' && (
          <div className="page-wrap">
            <span className="eyebrow">02 · Aplicación</span>
            <h1 style={{ margin: '15px 0 14px' }}>Selección de<br /><em style={{ color: 'hsl(var(--primary))' }}>unidades.</em></h1>
            <p className="lede">La unidad adecuada depende de la longitud que se mide y del nivel de precisión requerido.</p>
            <div className="note-callout">
              <Compass size={19} aria-hidden="true" />
              <p><strong>Criterio de selección:</strong> usá una unidad mayor para distancias extensas y una unidad menor cuando necesitás expresar más detalle.</p>
            </div>
            <div className="section-heading" style={{ marginTop: 32 }}>
              <div><span className="eyebrow">Ejemplos de uso</span><h2 style={{ margin: '10px 0 0' }}>Longitudes cotidianas</h2></div>
              <p>La elección depende de la escala<br />y la precisión necesarias.</p>
            </div>
            <div className="context-grid">
              {contexts.map(([title, explanation, unit], index) => (
                <article className="context-item" key={title} data-testid={`contexto-${index + 1}`}>
                  <span className="context-num">{String(index + 1).padStart(2, '0')}</span>
                  <div><strong>{title}</strong><p>{explanation}</p></div>
                  <span className="context-unit" aria-label={`Unidad recomendada: ${unit}`}>{unit}</span>
                </article>
              ))}
            </div>
            <div className="fact-strip">
              <strong>Mayor nivel de precisión</strong>
              <span>UNIDADES MENORES: m → dm → cm → mm</span>
            </div>
          </div>
        )}

        {section === 'mision' && (
          <div className="page-wrap">
            <span className="eyebrow">03 · Práctica</span>
            <h1 style={{ margin: '15px 0 14px' }}>Ejercicios de<br /><em style={{ color: 'hsl(var(--primary))' }}>conversión.</em></h1>
            <p className="lede">Resolvé doce ejercicios de conversión y selección de unidades. Cada respuesta incluye una explicación del procedimiento. No hay límite de tiempo.</p>
            <div className="mission-layout">
              <section className="mission-card" aria-label="Ejercicio de práctica">
                {!roundComplete ? (
                  <>
                    <div className="mission-progress-head">
                      <span data-testid="status-numero-pregunta">Ejercicio {questionIndex + 1} de {questions.length}</span>
                      <span data-testid="status-puntaje">Aciertos: {roundScore}</span>
                    </div>
                    <div className="progress-track" role="progressbar" aria-label="Progreso de la práctica" aria-valuemin={0} aria-valuemax={questions.length} aria-valuenow={questionIndex}>
                      <div className="progress-fill" style={{ width: `${progressPercent}%` }} />
                    </div>
                    <span className="question-type">{currentQuestion.questionLabel}</span>
                    <h2 className="question-title" data-testid="texto-pregunta">{currentQuestion.prompt}</h2>
                    {currentQuestion.kind === 'choice' ? (
                      <div className="answer-options" role="group" aria-label="Opciones de respuesta">
                        {currentQuestion.choices?.map((choice, index) => {
                          const stateClass = checkedAnswer
                            ? choice === currentQuestion.answer ? 'correct' : choice === selectedAnswer ? 'incorrect' : ''
                            : '';
                          return (
                            <button
                              key={choice}
                              type="button"
                              className={`answer-choice ${stateClass}`}
                              onClick={() => answerChoice(choice)}
                              disabled={checkedAnswer}
                              aria-pressed={selectedAnswer === choice}
                              data-testid={`respuesta-opcion-${index + 1}`}
                            >
                              <span className="choice-letter">{String.fromCharCode(65 + index)}</span>{choice}
                              {checkedAnswer && choice === currentQuestion.answer && <Check size={17} aria-label="Respuesta correcta" />}
                            </button>
                          );
                        })}
                      </div>
                    ) : (
                      <form className="typed-row" onSubmit={submitTyped}>
                        <label className="sr-only" htmlFor="typed-answer">Ingresá tu respuesta numérica en {currentQuestion.unit}</label>
                        <input
                          id="typed-answer"
                          type="text"
                          inputMode="numeric"
                          autoComplete="off"
                          value={typedAnswer}
                          onChange={(event) => setTypedAnswer(event.target.value)}
                          placeholder={`Respuesta en ${currentQuestion.unit}`}
                          disabled={checkedAnswer}
                          aria-describedby={checkedAnswer ? 'answer-feedback' : undefined}
                          data-testid="input-respuesta-numerica"
                        />
                        <button className="button button-primary" type="submit" disabled={checkedAnswer || !typedAnswer.trim()} data-testid="button-comprobar">Comprobar respuesta</button>
                      </form>
                    )}
                    {checkedAnswer && (
                      <div id="answer-feedback" className={`feedback ${isCorrect ? 'good' : 'try-again'}`} role="status" aria-live="polite" data-testid="feedback-respuesta">
                        {isCorrect ? <Check size={19} aria-hidden="true" /> : <Lightbulb size={19} aria-hidden="true" />}
                        <div>
                          <strong>{isCorrect ? 'Respuesta correcta.' : `Respuesta incorrecta. La respuesta correcta es ${currentQuestion.answer}.`}</strong>
                          <p>{currentQuestion.explanation}</p>
                        </div>
                      </div>
                    )}
                    {checkedAnswer && (
                      <div className="next-row">
                        <button className="button button-primary" onClick={advanceQuestion} data-testid="button-siguiente">
                          {questionIndex === questions.length - 1 ? 'Ver resultados' : 'Siguiente ejercicio'} <ArrowRight size={16} />
                        </button>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="completion" data-testid="estado-mision-completa">
                    <div className="completion-mark"><Check size={29} /></div>
                    <span className="eyebrow">Práctica finalizada</span>
                    <h2>Resultado de la práctica</h2>
                    <p>Revisá tus respuestas y los procedimientos. Podés repetir los ejercicios para seguir practicando.</p>
                    <div className="completion-score">
                      <div><strong>{roundScore}/{questions.length}</strong><span>respuestas correctas</span></div>
                      <div><strong>{bestScore}</strong><span>mejor resultado</span></div>
                    </div>
                    <button className="button button-primary" onClick={replayMission} data-testid="button-repetir-mision"><RotateCcw size={16} /> Repetir práctica</button>
                  </div>
                )}
              </section>
              <aside className="mission-side" aria-label="Progreso de práctica">
                <h3>Progreso</h3>
                <div className="side-stat"><span>Aciertos seguidos</span><strong data-testid="status-racha">{streak}</strong></div>
                <div className="side-stat"><span>Mejor resultado</span><strong data-testid="status-mejor-puntaje">{bestScore}/{questions.length}</strong></div>
                <div className="side-stat"><span>Prácticas completadas</span><strong data-testid="status-misiones">{completedRounds}</strong></div>
                <div style={{ borderTop: '1px solid hsl(var(--border))', paddingTop: 15, marginTop: 3 }}>
                  <span className="eyebrow" style={{ color: 'hsl(var(--primary))' }}>Relaciones entre unidades</span>
                  <div style={{ font: '500 11px var(--app-font-mono)', lineHeight: 2.1, marginTop: 9 }} data-testid="escala-practica">
                    km <span style={{ color: 'hsl(var(--primary))' }}>— ×1.000 —</span> m<br />
                    m <span style={{ color: 'hsl(var(--primary))' }}>— ×100 —</span> cm<br />
                    cm <span style={{ color: 'hsl(var(--primary))' }}>— ×10 —</span> mm
                  </div>
                </div>
                <p style={{ fontSize: 11, lineHeight: 1.55, color: 'hsl(var(--muted-foreground))', margin: '14px 0 0' }}>Hacia una unidad menor, multiplicá. Hacia una unidad mayor, dividí por el mismo factor.</p>
              </aside>
            </div>
          </div>
        )}
      </main>
      <footer className="footer"><span>MATEMÁTICA · MEDIDAS DE LONGITUD</span><span>Sistema métrico decimal</span></footer>
    </div>
  );
}

export default App;
