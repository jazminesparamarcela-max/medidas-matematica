---
name: Tono de la aplicación de longitud
description: Preferencias editoriales y de identidad para la app educativa de medidas de longitud.
---

No agregar un nombre creativo ni una marca a la aplicación. Usar “medidas de longitud” solo como descripción del tema. Mantener un tono claro y profesional, adecuado para estudiantes de 13 años; evitar slogans, metáforas infantiles y frases que presenten el contenido como adivinanzas.

**Why:** El usuario pidió explícitamente una presentación profesional para estudiantes de 13 años y rechazó el nombre inventado y el lenguaje infantil.

**How to apply:** Mantener este criterio en la interfaz, el contenido, los metadatos y futuras ampliaciones de esta aplicación.
