# Resumen del pedido y código (para pasar a otra IA)

## Qué pidió la docente
Una aplicación web interactiva, en español rioplatense (Argentina), para enseñar **medidas de longitud** a sus alumnos (nivel primaria). Se comparte por WhatsApp con un enlace, sin cuentas ni instalaciones (hosting gratuito tipo GitHub Pages).

### Contenido pedido
1. **Explicación general** de las unidades de longitud y sus conversiones (km, hm, dam, m, dm, cm, mm), con la relación de cuándo se "agregan ceros" y cuándo se "sacan".
2. **Criterio para elegir la unidad** según el caso, con muchos ejemplos: medir una casa o terreno (m), distancia entre pueblos (km), confeccionar una prenda (cm), piezas o tornillos (mm), etc.
3. **Ejercitación**: convertir de una unidad a otra con opción múltiple; el alumno toca y ve si es correcto o incorrecto. Que sea divertido, tipo juego ("sorpréndeme").

### Correcciones y preferencias que fue dando (en orden)
- Diseño: "todo está muy junto, no me gusta" → más espacio, botones más grandes, mejores colores.
- Estética: usar la del póster de **Hoppers (Disney Pixar, "Reptile Queens")**: fondo amarillo mostaza, texto marrón casi negro, coral y verde como acentos, tipografía ancha y geométrica para títulos.
- La explicación de "subir y bajar escalones" **no se entendía**: pidió otra forma de decirlo y mostrarlo gráficamente.
- Rigor matemático: pidió **fundamento en libros/fuentes de matemática, sin errores**. El concepto base es **multiplicar o dividir por 10, 100, 1000** (cada unidad es 10 veces la de al lado). **Correr la coma es solo un atajo**, no la regla. En Argentina el decimal se escribe con **coma** (3,5) y los miles con punto (1.000).
- En el juego: mostrar la **escala de patrones**, usar **solo unidades comunes** (km, m, cm, mm; sin hectómetro, decámetro ni decímetro), **números relacionados con cientos y miles** (nada de 0,1 o 0,25) y **al menos 10 ejercicios**.
- Dinámica del juego: rechazó el Pac-Man ("desde mi época") y luego los globos que suben ("seguís en los 80'"). Quiere algo **moderno** (estilo apps de aprendizaje actuales), no arcade retro.
- Quiere poder compartir libremente por WhatsApp, sin actualizar nada.

## Estado actual
- Tres pestañas: **1. Aprender**, **2. ¿Cuál uso?**, **3. Jugar** ("Misión Medidas").
- Aprender: cadena de unidades, tarjetas "a unidad más chica se multiplica / a más grande se divide", tira de unidades + convertidor que muestra el número en fichas con ceros nuevos resaltados y el factor (×10, ×100, ×1000).
- ¿Cuál uso?: 10 casos reales con la unidad recomendada y el porqué.
- Jugar: pantalla completa estilo lección moderna (barra de progreso, vidas, XP, racha, cartel verde/rojo al comprobar, confeti, sonido y vibración), 10 desafíos por partida, mezcla de opción múltiple y respuesta escrita, y 3 preguntas de "qué unidad conviene".
- Es **un solo archivo HTML** (CSS y JS adentro). Para publicar: renombrar a `index.html`.

## Pendientes / cosas a mejorar (sugerido para la otra IA)
- **Limpiar código muerto**: quedan restos del juego anterior (funciones `mkQ`, `pick`, `ask`, `finish`, `newGame`, secciones `#start/#game/#end` ocultas con CSS, estilos de globos `.bub`, etc.). Se puede borrar todo eso y los estilos que se pisan entre sí.
- Revisar el diseño en celular real (la docente no lo probó todavía y es muy exigente con lo visual).
- La docente sigue buscando una dinámica más moderna y menos "tradicional"; ideas: misiones con contexto, ejercicios de arrastrar, mascota (reptil estilo Hoppers), mapa de niveles.
- Mantener: español de Argentina, coma decimal, solo km/m/cm/mm en el juego, números enteros y de cientos/miles, explicación basada en multiplicar/dividir por 10, 100, 1000.

## Código completo (archivo único: index.html)

```html
<!DOCTYPE html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Come-Ceros: medidas de longitud</title>
<link href="https://fonts.googleapis.com/css2?family=Michroma&family=Space+Grotesk:wght@400;500;700&display=swap" rel="stylesheet">
<style>
:root{--bg:#f6f3e8;--sf:#fff;--tx:#1d2433;--mu:#5a6478;--ac:#ffc400;--bl:#1f3fbf;--ok:#1a8f4d;--no:#d1344a;--ln:#d9d4c0;
box-sizing:border-box;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#10142b;--sf:#1a2042;--tx:#f1efe6;--mu:#a3abc9;--bl:#7f98ff;--ln:#323a6b;--ok:#4ade80;--no:#ff6b81}}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--tx);font:17px/1.5 'Fredoka',system-ui,sans-serif}
main{max-width:720px;margin:0 auto;padding:16px}
h1{font-size:1.7rem;margin:.2em 0}h2{font-size:1.3rem;margin:1.2em 0 .4em}
p{margin:.4em 0}
nav{display:flex;gap:6px;position:sticky;top:env(safe-area-inset-top,0px);background:var(--bg);padding:8px 0;z-index:5}
nav button{flex:1;padding:10px 4px;border:2px solid var(--bl);background:var(--sf);color:var(--tx);border-radius:12px;font:600 .95rem 'Fredoka',system-ui,sans-serif;cursor:pointer}
nav button[aria-selected=true]{background:var(--bl);color:#fff}
button:focus-visible,input:focus-visible,select:focus-visible{outline:3px solid var(--ac);outline-offset:2px}
.box{background:var(--sf);border:2px solid var(--ln);border-radius:14px;padding:14px;margin:12px 0}
.ladder{display:flex;flex-direction:column;gap:0}
.step{display:flex;align-items:center;gap:10px;padding:8px 12px;margin-left:calc(var(--i)*14px);border-radius:10px;background:var(--sf);border:2px solid var(--ln);margin-bottom:-2px;cursor:pointer;font-weight:600}
.step b{font-size:1.2rem;min-width:3ch}.step span{color:var(--mu);font-weight:400;font-size:.9rem}
.step.sel{border-color:var(--bl);background:var(--bl);color:#fff}.step.sel span{color:#fff}
.arrows{display:flex;justify-content:space-between;gap:8px;margin:10px 0;font-weight:600}
.arrows div{flex:1;border-radius:10px;padding:8px;text-align:center}
.dn{background:#ffe9a8;color:#3b2f00}.up{background:#cfe0ff;color:#0d2060}
.conv{display:grid;grid-template-columns:1fr 1fr;gap:8px}.conv input,.conv select{width:100%;padding:10px;font:inherit;border-radius:10px;border:2px solid var(--ln);background:var(--bg);color:var(--tx)}
.res{font-size:1.4rem;font-weight:700;margin-top:10px}
.cases{display:grid;gap:8px}
.case{display:flex;justify-content:space-between;gap:10px;align-items:center;background:var(--sf);border:2px solid var(--ln);border-radius:12px;padding:10px 12px}
.case em{font-style:normal;font-weight:700;color:#3b2f00;background:var(--ac);border-radius:8px;padding:2px 10px;white-space:nowrap}
.zero{display:inline-block;background:var(--ac);color:#3b2f00;border-radius:50%;width:1.4em;height:1.4em;text-align:center;line-height:1.4em;font-weight:700;margin:0 1px}
.go{display:block;width:100%;padding:14px;border:0;border-radius:14px;background:var(--ac);color:#3b2f00;font:700 1.15rem 'Fredoka',system-ui,sans-serif;cursor:pointer}
.hud{display:flex;justify-content:space-between;font-weight:700;font-size:1.1rem}
.track{position:relative;height:50px;margin:12px 6px;background:var(--sf);border:2px solid var(--ln);border-radius:30px;overflow:hidden}
.dots{position:absolute;inset:0 20px 0 50px;display:flex;justify-content:space-between;align-items:center}
.dot{width:12px;height:12px;border-radius:50%;background:var(--ac);transition:transform .2s}.dot.eaten{transform:scale(0)}
.pac{position:absolute;top:7px;left:6px;width:34px;height:34px;border-radius:50%;background:var(--ac);animation:chomp .35s infinite alternate;transition:left .5s}
@keyframes chomp{from{clip-path:polygon(50% 50%,100% 10%,100% 0,0 0,0 100%,100% 100%,100% 90%)}to{clip-path:polygon(50% 50%,100% 50%,100% 0,0 0,0 100%,100% 100%)}}
.ghost{position:absolute;right:8px;top:7px;font-size:1.7rem;transition:transform .3s}
.ghost.hit{transform:translateX(-40px) rotate(-15deg)}
.q{font-size:1.35rem;font-weight:600;margin:10px 0}
.opts{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.opt{padding:16px 6px;font:700 1.2rem 'Fredoka',system-ui,sans-serif;border:3px solid var(--bl);background:var(--sf);color:var(--tx);border-radius:14px;cursor:pointer}
.opt.good{background:var(--ok);border-color:var(--ok);color:#fff}.opt.bad{background:var(--no);border-color:var(--no);color:#fff}
.fb{min-height:3.2em;margin-top:10px;font-weight:600}
.hidden{display:none}
@media (prefers-reduced-motion:reduce){.pac{animation:none}*{transition:none!important}}
:root{--bg:#eef0fb;--sf:#fff;--tx:#1b1e3b;--mu:#666b8c;--ac:#ffc83d;--bl:#5b3df5;--ln:#e1e4f5;--ok:#17a566;--no:#e5484d;--o1:#e6e1ff;--o2:#ffe6dc;--o3:#d8f4e6;--o4:#fff0c2;--sh:0 8px 24px rgba(40,40,110,.10)}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#0e1024;--sf:#181b3a;--tx:#f2f1ff;--mu:#a9aed3;--bl:#8f7cff;--ln:#2a2e5c;--o1:#2d2770;--o2:#4d2c38;--o3:#1a483c;--o4:#4b4120;--sh:none}}
body{font-size:18px;line-height:1.65}
main{padding:24px 20px 56px}
h1{font-size:2.1rem;line-height:1.15;margin:.3em 0 .2em}
h2{font-size:1.4rem;margin:2em 0 .7em}
main>p{color:var(--mu);margin-bottom:18px}
nav{gap:10px;padding:14px 0 18px}
nav button{min-height:52px;border:0;border-radius:999px;background:var(--sf);box-shadow:var(--sh);font-size:1rem;padding:8px 6px}
nav button[aria-selected=true]{background:var(--bl);color:#fff}
.box{border:0;border-radius:22px;padding:24px;margin:26px 0;box-shadow:var(--sh)}
.box p{margin:.7em 0}
.ladder{gap:10px}
.step{margin-bottom:0;padding:16px 18px;border:0;border-radius:16px;box-shadow:var(--sh);gap:14px}
.step.sel{background:var(--bl);color:#fff}
.arrows{gap:16px;margin:28px 0}
.arrows div{padding:18px 14px;border-radius:18px;line-height:1.45}
.conv{gap:16px}
.conv input,.conv select{padding:15px;border:2px solid var(--ln);border-radius:14px;background:var(--bg)}
.res{margin-top:22px;font-size:1.5rem;color:var(--bl)}
.cases{gap:16px}
.case{padding:18px 20px;border:0;border-radius:18px;box-shadow:var(--sh);gap:16px}
.case em{padding:6px 16px;border-radius:999px}
.go{margin-top:36px;padding:20px;border-radius:999px;background:var(--bl);color:#fff;box-shadow:0 6px 0 rgba(0,0,0,.25);transition:transform .1s,box-shadow .1s}
.go:active{transform:translateY(4px);box-shadow:0 2px 0 rgba(0,0,0,.25)}
#start,#end,#game{background:#171a3a;color:#fff;border-radius:26px;padding:26px 22px;box-shadow:var(--sh)}
#start .go,#end .go,#game .go{background:var(--ac);color:#2b2200}
#start,#end{margin:20px 0}
.hud{padding:0 4px 4px;font-size:1.15rem}
.track{height:58px;margin:20px 0 26px;background:#0b0d22;border:2px solid #343a7a}
.pac{top:11px}.ghost{top:10px}
.q{margin:8px 0 24px;font-size:1.45rem;line-height:1.4}
.opts{gap:18px}
.opts .opt{min-height:78px;padding:14px 8px;border:0;border-radius:20px;color:#1b1e3b;box-shadow:0 6px 0 rgba(0,0,0,.35);transition:transform .1s}
.opts .opt:active{transform:translateY(4px)}
.opts .opt:nth-child(1){background:#d9d2ff}.opts .opt:nth-child(2){background:#ffd9c9}.opts .opt:nth-child(3){background:#c9f1de}.opts .opt:nth-child(4){background:#ffeaa8}
.opts .opt.good{background:var(--ok);color:#fff}.opts .opt.bad{background:var(--no);color:#fff}
.opts .opt:disabled:not(.good):not(.bad){opacity:.55}
.fb{min-height:4.5em;margin:22px 0 4px;color:#e9e8ff;line-height:1.5}
#nx{margin-top:12px}
@media (max-width:420px){.arrows{flex-direction:column}.conv{grid-template-columns:1fr}}
:root,:root:not([data-theme="light"]){--bg:#e9b325;--sf:#fff3cf;--tx:#2a1409;--mu:#6b4a22;--ac:#ffd34d;--bl:#2a1409;--ln:#2a1409;--ok:#3e9a35;--no:#c4372b;--sh:none}
body,button,input,select,.opts .opt,.go,nav button{font-family:'Space Grotesk',system-ui,sans-serif}
body{background:var(--bg);color:var(--tx)}
h1,h2,nav button,.go,.hud{font-family:'Michroma','Space Grotesk',system-ui,sans-serif;text-transform:uppercase;letter-spacing:.03em}
h1{font-size:1.55rem;line-height:1.25}
h2{font-size:1rem;line-height:1.5}
main>p{color:#4a2f10;font-weight:500}
nav button{font-size:.68rem;border:2px solid #2a1409;background:var(--sf);color:#2a1409;box-shadow:none}
nav button[aria-selected=true]{background:#2a1409;color:#fff3cf}
.box,.step,.case{background:var(--sf);border:2px solid #2a1409;box-shadow:none}
.step.sel{background:#ef8b72;color:#2a1409}.step.sel span{color:#2a1409}
.dn{background:#ef8b72;color:#2a1409}.up{background:#8cc56a;color:#2a1409}
.arrows div{border:2px solid #2a1409}
.zero{background:#ef8b72;color:#2a1409}
.case em{background:#8cc56a;color:#2a1409;border:2px solid #2a1409}
.conv input,.conv select{background:#fff;border:2px solid #2a1409;color:#2a1409}
.res{color:#a83a24}
.go{font-size:.85rem;background:#2a1409;color:#fff3cf;box-shadow:0 6px 0 #8a5a12}
#start,#end,#game{background:#2a1409;color:#fff3cf;border:0}
#start .go,#end .go,#game .go{background:#e9b325;color:#2a1409;box-shadow:0 6px 0 #8a5a12}
.hud{font-size:.85rem}
.track{background:#1a0b04;border:2px solid #6b4a22}
.dot{background:#ef8b72}
.pac{background:#ffd34d}
.q{color:#fff3cf;font-weight:700}
.opts .opt{color:#2a1409;box-shadow:0 6px 0 #000}
.opts .opt:nth-child(1){background:#ef8b72}.opts .opt:nth-child(2){background:#8cc56a}.opts .opt:nth-child(3){background:#f3d18a}.opts .opt:nth-child(4){background:#f6b7a6}
.opts .opt.good{background:#3e9a35;color:#fff}.opts .opt.bad{background:#c4372b;color:#fff}
.fb{color:#fff3cf}
.strip{display:flex;border:2px solid #2a1409;border-radius:14px;overflow:hidden;margin:6px 0}
.cell{flex:1;padding:14px 0;border:0;border-right:2px solid #2a1409;background:#fff3cf;color:#2a1409;font:700 .95rem 'Space Grotesk',system-ui,sans-serif;cursor:pointer}
.cell:last-child{border-right:0}.cell.f{background:#ef8b72}.cell.t2{background:#8cc56a}
.sl{display:flex;justify-content:space-between;font-size:.8rem;color:var(--mu);font-weight:700}
.tiles{display:flex;gap:5px;flex-wrap:wrap;align-items:flex-end}
.t{font-style:normal;font-weight:700;font-size:1.5rem;min-width:2ch;text-align:center;padding:6px 6px;background:#fff;border:2px solid #2a1409;border-radius:10px}
.t.c{background:transparent;border:0;min-width:0;padding:0 1px;color:#a83a24;font-size:2.2rem;line-height:1}
.t.add{background:#ffd34d}
.rowlab{font-size:.85rem;color:var(--mu);margin:18px 0 8px;font-weight:700}
.scale{display:flex;align-items:center;justify-content:center;gap:8px;flex-wrap:wrap;background:#1a0b04;border:2px solid #6b4a22;border-radius:16px;padding:14px 10px;margin:16px 0 6px;font-weight:700;font-size:1.05rem}
.scale b{background:#e9b325;color:#2a1409;border-radius:10px;padding:6px 14px}
.scale i{font-style:normal;color:#ef8b72;font-size:.85rem}
.scaleh{text-align:center;font-size:.85rem;color:#e9d9b0;margin-bottom:6px}
#opts{display:block;position:relative;height:380px;overflow:hidden;border-radius:18px;background:radial-gradient(circle at 50% 100%,#3a1f0f,#1a0b04);border:2px solid #6b4a22}
.bub{position:absolute;bottom:-110px;width:23%;aspect-ratio:1;border:0;border-radius:50%;background:var(--c);color:#2a1409;font:700 clamp(.78rem,3.6vw,1.05rem)/1.15 'Space Grotesk',system-ui,sans-serif;padding:4px;cursor:pointer;box-shadow:inset -6px -8px 0 rgba(0,0,0,.18);animation:rise var(--d) linear forwards}
.bub small{display:block;font-size:.75em;font-weight:500}
@keyframes rise{to{transform:translateY(-520px)}}
.freeze .bub{animation-play-state:paused}
.bub.good{background:#3e9a35;color:#fff}.bub.bad{background:#c4372b;color:#fff}
@media (prefers-reduced-motion:reduce){.bub{animation-duration:16s!important}}
#start,#game,#end{display:none!important}
.ov{position:fixed;inset:0;z-index:50;background:#fff8e6;color:#2a1409;overflow:auto;font-family:'Space Grotesk',system-ui,sans-serif}
.ovin{max-width:560px;margin:0 auto;padding:calc(16px + env(safe-area-inset-top,0px)) 18px 220px}
.top{display:flex;align-items:center;gap:14px}
.top button{background:none;border:0;font-size:1.6rem;color:#8a6a3a;cursor:pointer;padding:4px 8px}
.bar{flex:1;height:16px;background:#ecdcb0;border-radius:99px;overflow:hidden}
.bar i{display:block;height:100%;width:0;background:#58b447;border-radius:99px;transition:width .5s;box-shadow:inset 0 5px 0 rgba(255,255,255,.35)}
#hp{font-weight:700;color:#d1344a}
.qc{margin:30px 0 22px}.em{font-size:3.4rem;line-height:1}.qc h3{font-size:1.5rem;line-height:1.3;margin:.35em 0}
.mini{display:flex;gap:8px;flex-wrap:wrap;align-items:center;font-size:.85rem;font-weight:700;color:#6b4a22;background:#f6e9c3;border-radius:14px;padding:10px 12px;margin-top:22px}
.mini span:nth-child(even){color:#c4563b}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.ch{padding:22px 6px;font:700 1.2rem 'Space Grotesk',system-ui,sans-serif;border:2px solid #e0cf9e;border-bottom-width:5px;border-radius:18px;background:#fff;color:#2a1409;cursor:pointer}
.ch.sel{border-color:#2a1409;background:#ffeeb0}.ch.right{border-color:#3e9a35;background:#d9f2cf}.ch.wrong{border-color:#c4372b;background:#ffd8d3}
.typ{display:flex;gap:12px;align-items:center}.typ b{font-size:1.4rem}
.typ input{flex:1;min-width:0;font:700 1.9rem 'Space Grotesk',system-ui,sans-serif;padding:14px 16px;border:2px solid #e0cf9e;border-bottom-width:5px;border-radius:18px;background:#fff;color:#2a1409}
.dock{position:fixed;left:0;right:0;bottom:0;padding:16px 18px calc(16px + env(safe-area-inset-bottom,0px));background:#fff8e6;border-top:2px solid #ecdcb0}
.dock.ok{background:#d9f2cf;border-color:#b7e3a8}.dock.no{background:#ffd8d3;border-color:#f5b3ab}
.dock .msg{max-width:560px;margin:0 auto 14px;line-height:1.45;font-weight:500}.dock .msg b{display:block;font-size:1.25rem;margin-bottom:2px}
.cta{display:block;width:100%;max-width:560px;margin:0 auto 10px;padding:16px;border:0;border-bottom:5px solid #2f6f28;border-radius:16px;background:#58b447;color:#fff;font:700 1.05rem 'Space Grotesk',system-ui,sans-serif;letter-spacing:.05em;cursor:pointer}
.cta:disabled{background:#e6dcc0;border-bottom-color:#cfc39f;color:#a29878;cursor:default}
.dock.no .cta{background:#e5484d;border-bottom-color:#a62a2e}
.cta.sec{background:#fff;color:#2a1409;border:2px solid #e0cf9e;border-bottom-width:5px}
.fin{text-align:center;padding-top:36px}.fin h3{font-size:1.6rem;margin:.3em 0}.xpb{font-size:2.6rem;font-weight:700;color:#d9951a;margin:.1em 0}
.cf{position:fixed;top:-20px;width:10px;height:14px;z-index:60;animation:fall 2.6s ease-in forwards}
@keyframes fall{to{transform:translateY(110vh) rotate(720deg)}}
</style></head><body><main>
<h1>Come-Ceros</h1>
<p>Aprendé las medidas de longitud y jugá a convertirlas.</p>
<nav role="tablist">
<button role="tab" aria-selected="true" data-t="a">1. Aprender</button>
<button role="tab" aria-selected="false" data-t="b">2. ¿Cuál uso?</button>
<button role="tab" aria-selected="false" data-t="c">3. Jugar</button></nav>

<section id="a">
<h2>La idea en simple</h2>
<div class="box"><p>Las unidades van de la más grande a la más chica. Cada una es <b>10 veces</b> la de al lado:</p><p style="font-weight:700;font-size:1.05rem">km → hm → dam → <span style="background:#ffd34d;padding:0 6px">m</span> → dm → cm → mm</p><p>Una unidad más chica entra más veces: en 1 m entran 100 cm. Por eso, <b>al cambiar de unidad, el número cambia al revés</b>.</p></div>
<div class="arrows"><div class="dn"><b>A una unidad MÁS CHICA</b> (a la derecha)<br>Se <b>multiplica</b> por 10, 100, 1000…<br>El número crece.</div><div class="up"><b>A una unidad MÁS GRANDE</b> (a la izquierda)<br>Se <b>divide</b> por 10, 100, 1000…<br>El número se achica.</div></div>
<p>Por <b>cada casillero</b> que te movés, multiplicás o dividís <b>por 10</b>. Dos casilleros: ×100. Tres: ×1000.</p>
<p><b>Atajo:</b> multiplicar por 10, 100 o 1000 es lo mismo que correr la coma decimal 1, 2 o 3 lugares a la derecha; dividir, a la izquierda. (En Argentina el decimal se escribe con coma: 3,5.)</p>
<div class="box"><b>Equivalencias que conviene saber</b>
<p>1 km = 1000 m &nbsp;·&nbsp; 1 m = 100 cm &nbsp;·&nbsp; 1 m = 1000 mm &nbsp;·&nbsp; 1 cm = 10 mm</p></div>
<div class="box"><b>Ejemplos</b>
<p>3 km a m: 3 casilleros hacia unidades más chicas → 3 × 1000 = 3000 m.</p>
<p>250 cm a m: 2 casilleros hacia unidades más grandes → 250 ÷ 100 = 2,5 m.</p>
<p>4,5 m a mm: 3 casilleros hacia más chicas → 4,5 × 1000 = 4500 mm.</p>
<p>35 mm a cm: 1 casillero hacia más grandes → 35 ÷ 10 = 3,5 cm.</p></div>
<h2>Probalo: mirá qué le pasa al número</h2>
<div class="box"><div class="sl"><span>← unidades más grandes</span><span>más chicas →</span></div><div class="strip" id="lad"></div><p style="color:var(--mu);font-size:.9rem">Tocá una unidad para usarla como punto de partida.</p><div class="conv">
<input id="cv" type="number" step="any" value="3" aria-label="Valor">
<select id="cf" aria-label="De"></select>
<select id="ct" aria-label="A"></select><div></div></div>
<div id="tl"></div><div class="res" id="cr"></div><p id="cs" style="color:var(--mu)"></p></div>
<button class="go" onclick="tab('b')">Siguiente: ¿qué medida elijo?</button>
</section>

<section id="b" class="hidden">
<h2>El criterio</h2>
<div class="box"><p><b>Elegí la unidad que te deje un número cómodo</b> (ni larguísimo ni lleno de decimales), y que tenga la precisión que necesitás.</p>
<p>Más precisión necesaria → unidad más chica. Distancias enormes → unidad más grande.</p></div>
<div class="cases" id="cases"></div>
<h2>Probá con tu caso</h2>
<div class="box"><p>Un largo de 3500 mm es lo mismo que 350 cm o 3,5 m. Para una pared, 3,5 m se lee y se entiende mejor. Para una pieza de precisión, 3500 mm es más claro.</p>
<p>Una ruta de 12.000.000 mm es 12 km: ¡mucho más fácil!</p></div>
<button class="go" onclick="tab('c')">¡A jugar!</button>
</section>

<section id="c" class="hidden">
<div class="box" style="text-align:center"><div style="font-size:3.2rem">🦎</div><h2 style="margin-top:.2em">Misión Medidas</h2><p>10 desafíos con situaciones reales. Ganás XP, armás tu racha y cuidás tus 3 vidas.</p><button class="go" onclick="startM()">Empezar misión</button></div>
<div id="start" class="box" style="text-align:center">
<h2 style="margin-top:0">Ayudá a Chompi a comer los puntos</h2>
<p>Las respuestas suben como globos. Tocá la correcta antes de que se escape: Chompi se la come y sumás puntos (con racha, más). Si tocás una incorrecta o se escapa la correcta, perdés una vida. Tenés 3 vidas y 10 preguntas, y cada vez van más rápido.</p>
<button class="go" onclick="newGame()">Empezar</button></div>
<div id="game" class="hidden">
<div class="hud"><span id="sc">⭐ 0</span><span id="lv">❤️❤️❤️</span><span id="nq">1/10</span></div>
<div class="scale"><b>km</b><i>×1000</i><b>m</b><i>×100</i><b>cm</b><i>×10</i><b>mm</b></div><div class="scaleh">Hacia la derecha multiplicás · hacia la izquierda dividís</div>
<div class="track"><div class="dots" id="dots"></div><div class="pac" id="pac"></div><div class="ghost" id="gh" aria-hidden="true">👻</div></div>
<div class="q" id="q"></div><div class="opts" id="opts"></div>
<div class="fb" id="fb" aria-live="polite"></div>
<button class="go hidden" id="nx">Siguiente</button></div>
<div id="end" class="box hidden" style="text-align:center"></div>
</section>
</main>
<div id="ov" class="ov hidden"><div class="ovin"><div class="top"><button id="x" aria-label="Salir">✕</button><div class="bar"><i id="bf"></i></div><span id="hp"></span></div><div id="stage"></div></div><div id="dock" class="dock"></div></div>
<script>
var U=[["km","kilómetro",3,"carreteras, distancia entre pueblos"],["hm","hectómetro",2,"poco usado"],["dam","decámetro",1,"poco usado"],["m","metro",0,"casas, terrenos, habitaciones"],["dm","decímetro",-1,"poco usado"],["cm","centímetro",-2,"ropa, muebles, personas"],["mm","milímetro",-3,"piezas, tornillos, planos finos"]];
var E={};U.forEach(function(u){E[u[0]]=u[2]});
function $(i){return document.getElementById(i)}
function fmt(n){return Number(n).toLocaleString('es-AR',{maximumFractionDigits:6})}
function cvt(v,a,b){return parseFloat((v*Math.pow(10,E[a]-E[b])).toPrecision(12))}
function why(v,a,b){var d=E[a]-E[b],n=Math.abs(d);if(!n)return"Es la misma unidad.";
return d>0?"De "+a+" a "+b+" hay "+n+" casillero(s) hacia unidades más chicas: se multiplica por 10, "+n+" vez/veces, o sea ×"+Math.pow(10,n)+". (Atajo: la coma se corre "+n+" lugar(es) a la derecha.)":"De "+a+" a "+b+" hay "+n+" casillero(s) hacia unidades más grandes: se divide por 10, "+n+" vez/veces, o sea ÷"+Math.pow(10,n)+". (Atajo: la coma se corre "+n+" lugar(es) a la izquierda.)"}
function tab(t){["a","b","c"].forEach(function(x){$(x).classList.toggle("hidden",x!=t)});
document.querySelectorAll("nav button").forEach(function(b){b.setAttribute("aria-selected",b.dataset.t==t)});window.scrollTo(0,0)}
document.querySelectorAll("nav button").forEach(function(b){b.onclick=function(){tab(b.dataset.t)}});
// escalera
var lad=$("lad");U.forEach(function(u){var d=document.createElement("button");d.className="cell";d.dataset.u=u[0];d.textContent=u[0];d.title=u[1];d.onclick=function(){$("cf").value=u[0];calc()};lad.appendChild(d)});
function tl(D,p,ad){var h='<div class="tiles">';for(var i=0;i<D.length;i++){if(i==p)h+='<i class="t c">,</i>';h+='<i class="t'+(ad[i]?' add':'')+'">'+D[i]+'</i>'}return h+'</div>'}
U.forEach(function(u){["cf","ct"].forEach(function(id){var o=document.createElement("option");o.value=u[0];o.textContent=u[0]+" ("+u[1]+")";$(id).appendChild(o)})});
$("cf").value="km";$("ct").value="m";
function calc(){var s=$("cv").value,a=$("cf").value,b=$("ct").value;
document.querySelectorAll(".cell").forEach(function(c){c.classList.toggle("f",c.dataset.u==a);c.classList.toggle("t2",c.dataset.u==b&&a!=b)});
if(!/^\d*\.?\d+$/.test(s)){$("cr").textContent="";$("cs").textContent="";$("tl").innerHTML="";return}
var ip=s.split(".")[0]||"0",fp=s.split(".")[1]||"",D=ip+fp,p=ip.length,ad=[],k=E[a]-E[b],o=tl(D.split(""),p,[]);
if(k>0){p+=k;while(D.length<p){D+="0";ad[D.length-1]=1}}
else if(k<0){p+=k;if(p<0){D=Array(1-p).join("0")+D;ad=Array(-p).fill(1);p=0}}
if(p==0){D="0"+D;ad.unshift(1);p=1}
D=D.split("");
while(p>1&&D[0]=="0"){D.shift();ad.shift();p--}
while(D.length>p&&D[D.length-1]=="0"&&!ad[D.length-1]){D.pop()}
var v=parseFloat(s);
$("tl").innerHTML='<div class="rowlab">Antes ('+a+')</div>'+o+'<div class="rowlab">Después ('+b+')'+(k?' · '+(k>0?'multiplicás':'dividís')+' por '+Math.pow(10,Math.abs(k)):'')+' · ceros nuevos en amarillo</div>'+tl(D,p,ad);
$("cr").textContent=fmt(v)+" "+a+" = "+fmt(cvt(v,a,b))+" "+b;$("cs").textContent=why(v,a,b)}
["cv","cf","ct"].forEach(function(i){$(i).oninput=calc});calc();
// casos
var C=[["Distancia de un pueblo a otro","km","Son miles de metros: en km queda 35 y no 35.000.000 mm."],["Largo de una casa o un terreno","m","Los planos de obra se hacen en metros (12 m x 8 m)."],["Altura de una pared o un techo","m","2,6 m es más cómodo que 260 cm."],["Ancho de una puerta o ventana","cm","90 cm es más natural que 0,9 m."],["Confeccionar una prenda (cintura, manga)","cm","Se mide con cinta métrica en cm, con medio centímetro de precisión."],["Largo de tela a comprar","m","La tela se vende por metro."],["Grosor de un tornillo o una chapa","mm","Pide precisión: 4 mm es mejor que 0,4 cm."],["Largo de un lápiz o de tu mano","cm","Entre 10 y 20 cm: número chico y fácil."],["Una carrera a pie","km","Se corren 5 km o 10 km."],["Ancho de un cabello o una hormiga","mm","Menos de 1 cm: usá mm."]];
C.forEach(function(c){var d=document.createElement("div");d.className="case";d.innerHTML="<div><b>"+c[0]+"</b><br><small style='color:var(--mu)'>"+c[2]+"</small></div><em>"+c[1]+"</em>";$("cases").appendChild(d)});
// juego
var G;
function rnd(a){return a[Math.floor(Math.random()*a.length)]}
function shuf(a){return a.sort(function(){return Math.random()-.5})}
function mkQ(i){
if(i%3==2){var c=rnd(C);var ops=shuf(["km","m","cm","mm"].filter(function(x){return x!=c[1]}).slice(0,3).concat([c[1]]).slice(0,4));
if(ops.indexOf(c[1])<0)ops[0]=c[1];ops=shuf(Array.from(new Set(ops)));
return{t:"¿Qué unidad conviene para: "+c[0].toLowerCase()+"?",o:ops,r:c[1],e:c[2]}}
var s=["km","m","cm","mm","dm","dam","hm"],a=rnd(s),b=rnd(s),k=0;
while((a==b||Math.abs(E[a]-E[b])>4)&&k++<50){a=rnd(s);b=rnd(s)}
if(a==b)b="m",a="cm";
var v=rnd([1,2,3,4,5,7,12,25,0.5,3.5,0.25,150,8]),r=cvt(v,a,b),set=[r,r*10,r/10,r*100,r/100].map(function(x){return parseFloat(x.toPrecision(12))});
set=Array.from(new Set(set));var ds=shuf(set.slice(1)).slice(0,3);
return{t:"Convertí: "+fmt(v)+" "+a+" a "+b,o:shuf([r].concat(ds)).map(function(x){return fmt(x)+" "+b}),r:fmt(r)+" "+b,e:why(v,a,b)+" Resultado: "+fmt(r)+" "+b+"."}}
function mkQ2(i){
if(i==0||!G.u)G.u=shuf(C.slice());
if(i%3==2){var c=G.u[(i-2)/3];return{t:"¿Qué unidad conviene para: "+c[0].toLowerCase()+"?",o:["km","m","cm","mm"],r:c[1],e:c[2]}}
var P=[["km","m"],["m","km"],["m","cm"],["cm","m"],["cm","mm"],["mm","cm"],["m","mm"],["mm","m"]],p=rnd(P);
while(p.join()==G.last)p=rnd(P);G.last=p.join();
var a=p[0],b=p[1],k=E[a]-E[b],n=Math.pow(10,Math.abs(k)),L=[2,3,5,8,12,15,20,25,50,100,150,200,250,300,500],v,r;
if(k>0){v=rnd(L);r=v*n}else{r=rnd(L);v=r*n}
var ds=shuf([r*10,r*100,r*1000,r/10,r/100].filter(function(x){return Number.isInteger(x)&&x!=r&&x>=1})).slice(0,3);
return{t:"Convertí: "+fmt(v)+" "+a+" a "+b,o:shuf([r].concat(ds)).map(function(x){return fmt(x)+" "+b}),r:fmt(r)+" "+b,e:why(v,a,b)+" Cuenta: "+fmt(v)+(k>0?" × ":" ÷ ")+fmt(n)+" = "+fmt(r)+" "+b+"."}}
function res2(ok,b){if(G.done)return;G.done=1;var q=G.q;$("opts").classList.add("freeze");
document.querySelectorAll(".bub").forEach(function(x){if(x.dataset.c=="1")x.classList.add("good")});
if(ok){G.c=(G.c||0)+1;var pts=10+5*Math.min(G.c-1,3);G.s+=pts;document.querySelectorAll(".dot")[G.i].classList.add("eaten");$("pac").style.left="calc("+((G.i+1)/10)+" * (100% - 90px) + 40px)";
$("fb").textContent="¡Ñam! +"+pts+(G.c>1?" · 🔥 racha x"+G.c:"")+". "+q.e}
else{G.c=0;if(b)b.classList.add("bad");G.l--;$("gh").classList.add("hit");$("fb").textContent=(b?"Ese no era. ":"Se escapó la respuesta correcta. ")+q.e}
G.i++;hud();var last=G.l<=0||G.i>=10;$("nx").textContent=last?"Ver resultado":"Siguiente";$("nx").classList.remove("hidden");$("nx").onclick=last?finish:ask}
function newGame(){G={i:0,s:0,l:3};$("start").classList.add("hidden");$("end").classList.add("hidden");$("game").classList.remove("hidden");
$("dots").innerHTML="";for(var i=0;i<10;i++){var d=document.createElement("div");d.className="dot";$("dots").appendChild(d)}
ask()}
function hud(){$("sc").textContent="⭐ "+G.s;$("lv").textContent="❤️".repeat(G.l)+"🖤".repeat(3-G.l);$("nq").textContent=Math.min(G.i+1,10)+"/10"}
function ask(){var q=mkQ2(G.i);G.q=q;hud();$("q").textContent=q.t;$("fb").textContent="";$("nx").classList.add("hidden");$("gh").classList.remove("hit");
var o=$("opts");o.innerHTML="";o.classList.remove("freeze");G.done=0;var xs=shuf([1,26,51,76]),dur=Math.max(5,9.5-G.i*.4);
q.o.forEach(function(t,j){var b=document.createElement("button");b.className="bub";b.dataset.c=t==q.r?"1":"0";b.style.left=xs[j]+"%";b.style.setProperty("--d",(dur+Math.random()*1.6).toFixed(1)+"s");b.style.setProperty("--c",["#ef8b72","#8cc56a","#f3d18a","#f6b7a6"][j]);var p=t.split(" ");b.innerHTML="<span>"+p[0]+(p[1]?"<small>"+p[1]+"</small>":"")+"</span>";b.onclick=function(){res2(t==q.r,b)};if(b.dataset.c=="1")b.addEventListener("animationend",function(){res2(false,null)});o.appendChild(b)})}
function pick(b,t){var q=G.q,ok=t==q.r;document.querySelectorAll(".opt").forEach(function(x){x.disabled=true;if(x.textContent==q.r)x.classList.add("good")});
if(ok){G.s+=10;var dots=document.querySelectorAll(".dot");dots[G.i].classList.add("eaten");$("pac").style.left="calc("+((G.i+1)/10)+" * (100% - 90px) + 40px)";
$("fb").textContent="¡Muy bien! ¡Ñam! +10. "+q.e}
else{b.classList.add("bad");G.l--;$("gh").classList.add("hit");$("fb").textContent="Ups, el fantasma te mordió. "+q.e}
G.i++;hud();var last=G.l<=0||G.i>=10;$("nx").textContent=last?"Ver resultado":"Siguiente";$("nx").classList.remove("hidden");$("nx").onclick=last?finish:ask}
function finish(){$("game").classList.add("hidden");var e=$("end");e.classList.remove("hidden");var w=G.l>0;
e.innerHTML="<h2 style='margin-top:0'>"+(w?"¡Chompi se comió todo!":"¡El fantasma ganó esta vez!")+"</h2><p>Puntos: <b>"+G.s+"</b> de 100</p><p>"+(G.s>=80?"Dominás las conversiones. 🏆":G.s>=50?"Vas muy bien, repasá la regla y volvé a jugar.":"Repasá: hacia una unidad más chica se multiplica, hacia una más grande se divide.")+"</p><button class='go' onclick='newGame()'>Jugar otra vez</button>";
$("pac").style.left="6px"}
var AC;function bp(f){try{AC=AC||new (window.AudioContext||window.webkitAudioContext)();var o=AC.createOscillator(),g=AC.createGain();o.frequency.value=f;g.gain.value=.07;o.connect(g);g.connect(AC.destination);o.start();o.stop(AC.currentTime+.14)}catch(e){}}
function vib(p){try{navigator.vibrate&&navigator.vibrate(p)}catch(e){}}
function confetti(){if(matchMedia("(prefers-reduced-motion:reduce)").matches)return;var cs=["#e9b325","#ef8b72","#8cc56a","#5b8def","#fff"];for(var i=0;i<50;i++){var s=document.createElement("span");s.className="cf";s.style.left=Math.random()*100+"%";s.style.background=cs[i%5];s.style.animationDelay=Math.random()*.6+"s";document.body.appendChild(s);setTimeout(function(e){e.remove()},3200,s)}}
var EM={"km|m":"🚌","m|km":"🚌","m|cm":"🧵","cm|m":"🧵","cm|mm":"🔩","mm|cm":"🔩","m|mm":"📐","mm|m":"📐"};
function startM(){G={i:0,hp:3,xp:0,st:0,ok:0};$("ov").classList.remove("hidden");document.body.style.overflow="hidden";mNext()}
function closeM(){$("ov").classList.add("hidden");document.body.style.overflow=""}
$("x").onclick=closeM;
function mNext(){if(G.hp<=0||G.i>=10)return mEnd();
var q=mkQ2(G.i);G.q=q;G.sel=null;$("bf").style.width=(G.i*10)+"%";$("hp").textContent="❤️ "+G.hp;
var mm=/^Convertí: (.+) (\S+) a (\S+)$/.exec(q.t),em="🧭",txt=q.t;G.typ=false;
if(mm){em=EM[mm[2]+"|"+mm[3]]||"📏";txt="Una medida de <b>"+mm[1]+" "+mm[2]+"</b>. ¿Cuántos <b>"+mm[3]+"</b> son?";G.typ=G.i%2==1}
var h='<div class="qc"><div class="em">'+em+'</div><h3>'+txt+'</h3></div>';
if(G.typ)h+='<div class="typ"><input id="ti" inputmode="numeric" autocomplete="off" aria-label="Tu respuesta"><b>'+mm[3]+'</b></div>';
else h+='<div class="grid">'+q.o.map(function(t,j){return '<button class="ch" data-j="'+j+'">'+t+'</button>'}).join("")+'</div>';
h+='<div class="mini"><span>km</span><span>×1000</span><span>m</span><span>×100</span><span>cm</span><span>×10</span><span>mm</span></div>';
$("stage").innerHTML=h;$("dock").className="dock";$("dock").innerHTML='<button class="cta" id="ck" disabled>COMPROBAR</button>';
if(G.typ){$("ti").oninput=function(){$("ck").disabled=!$("ti").value.trim()};$("ti").focus()}
else document.querySelectorAll(".ch").forEach(function(b){b.onclick=function(){G.sel=+b.dataset.j;document.querySelectorAll(".ch").forEach(function(x){x.classList.toggle("sel",x==b)});$("ck").disabled=false}});
$("ck").onclick=mCheck}
function mCheck(){var q=G.q,ok;
if(G.typ){var v=$("ti").value.replace(/[.\s]/g,"").replace(",","."),t=q.r.split(" ")[0].replace(/\./g,"").replace(",",".");ok=parseFloat(v)==parseFloat(t);$("ti").disabled=true}
else{ok=G.sel!=null&&q.o[G.sel]==q.r;document.querySelectorAll(".ch").forEach(function(b){b.disabled=true;var j=+b.dataset.j;if(q.o[j]==q.r)b.classList.add("right");else if(j==G.sel)b.classList.add("wrong")})}
var m;
if(ok){G.st++;G.ok++;var x=10+Math.min(G.st-1,4)*2;G.xp+=x;m="<b>¡Muy bien! +"+x+" XP</b>"+(G.st>1?"🔥 "+G.st+" seguidas · ":"")+q.e;bp(660);vib(20)}
else{G.st=0;G.hp--;m="<b>Respuesta correcta: "+q.r+"</b>"+q.e;bp(200);vib([40,30,40]);$("hp").textContent="❤️ "+G.hp}
$("dock").className="dock "+(ok?"ok":"no");$("dock").innerHTML='<div class="msg">'+m+'</div><button class="cta" id="cn">CONTINUAR</button>';$("cn").onclick=function(){G.i++;mNext()};$("cn").focus()}
function mEnd(){var win=G.hp>0;$("bf").style.width=win?"100%":(G.i*10)+"%";
var msg=G.ok>=9?"Dominás las conversiones. 🌟":G.ok>=6?"Vas muy bien. Un repaso más y lo tenés.":"Repasá: a una unidad más chica se multiplica, a una más grande se divide.";
$("stage").innerHTML='<div class="fin"><div style="font-size:4.2rem">'+(win?"🏆":"🦎")+'</div><h3>'+(win?"¡Misión cumplida!":"¡Casi! Se acabaron las vidas")+'</h3><p class="xpb">'+G.xp+' XP</p><p>Acertaste '+G.ok+' de '+Math.min(G.i,10)+'</p><p>'+msg+'</p></div>';
$("dock").className="dock";$("dock").innerHTML='<button class="cta" id="ag">JUGAR OTRA VEZ</button><button class="cta sec" id="ex">SALIR</button>';$("ag").onclick=startM;$("ex").onclick=closeM;if(win){confetti();bp(880)}}
</script></body></html>

```
